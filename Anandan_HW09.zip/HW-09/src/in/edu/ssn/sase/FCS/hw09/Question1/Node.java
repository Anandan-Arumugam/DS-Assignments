package in.edu.ssn.sase.FCS.hw09.Question1;

public class Node<T> {

	private T data;
	private Node<T> next;
	private boolean head;
	private boolean tail;
	private boolean deleted;
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public Node<T> getNext() {
		return next;
	}
	public void setNext(Node<T> next) {
		this.next = next;
	}
	public boolean isHead() {
		return head;
	}
	public void setHead(boolean head) {
		this.head = head;
	}
	public boolean isTail() {
		return tail;
	}
	public void setTail(boolean tail) {
		this.tail = tail;
	}
	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
}
